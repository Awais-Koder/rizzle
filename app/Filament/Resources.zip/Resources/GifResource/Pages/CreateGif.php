<?php

namespace App\Filament\Resources\GifResource\Pages;

use App\Filament\Resources\GifResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateGif extends CreateRecord
{
    protected static string $resource = GifResource::class;
}
